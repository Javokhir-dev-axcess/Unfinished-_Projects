import os
import speech_recognition as sr
import pyttsx3
from google import genai
from google.genai import types

engine = pyttsx3.init()
voices = engine.getProperty('voices')
if voices:
    engine.setProperty('voice', voices[0].id)
engine.setProperty('rate', 185) 

def speak(text):
    """Converts text to speech output."""
    print(f"Z: {text}")
    engine.say(text)
    engine.runAndWait()

api_key = os.environ.get("GEMINI_API_KEY")
if not api_key:
    raise ValueError("GEMINI_API_KEY environment variable is not set.")

client = genai.Client(api_key=api_key)

SYSTEM_INSTRUCTION = (
    "You are JARVIS, an elite, hyper-intelligent, and witty AI assistant created for Akajon. "
    "Keep your answers concise, highly professional, and slightly conversational, "
    "as if speaking through a high-end HUD interface."
)

def listen_command():
    """Listens to microphone input and converts it to text."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("\n🎤 Listening for command...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
            print("⚙️ Processing audio...")
            command = recognizer.recognize_google(audio)
            print(f"Akajon said: {command}")
            return command
        except sr.WaitTimeoutError:
            return None
        except sr.UnknownValueError:
            speak("I didn't catch that, Akajon. Could you repeat?")
            return None
        except sr.RequestError:
            speak("Network error with the speech recognition service.")
            return None

def main():
    speak("Systems online. All protocols operational. Ready for your command, Akajon.")
    
    while True:
        command = listen_command()
        if command:
            # Exit condition
            if "shutdown" in command.lower() or "go offline" in command.lower():
                speak("Shutting down systems. Goodbye, Akajon.")
                break

            try:
                response = client.models.generate_content(
                    model='gemini-2.0-flash',
                    contents=command,
                    config=types.GenerateContentConfig(
                        system_instruction=SYSTEM_INSTRUCTION,
                        max_output_tokens=150,
                    )
                )
                reply = response.text or "No response generated."
                speak(reply)
                
            except Exception as e:
                print(f"Error: {e}")
                speak("An error occurred while processing your request.")

if __name__ == "__main__":
    main()
