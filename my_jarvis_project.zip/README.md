JARVIS AI Voice Assistant

A lightweight, Python-based personal AI voice assistant powered by the Google Gemini API.
Features:

   1)Speech-to-Text: Listens to voice commands via your microphone.

   2)AI Brain: Processes queries and generates smart responses using gemini-2.0-flash.

   3)Text-to-Speech: Speaks responses back to you offline using pyttsx3.

Setup & Installation (Linux)

   1) Install required system packages:
   1)sudo apt update && sudo apt install python3-pip python3-venv portaudio19-dev -y

Create and activate a virtual environment:
   2)python3 -m venv jarvis_env
   2)source jarvis_env/bin/activate

Install Python dependencies:
   3)pip install SpeechRecognition pyttsx3 google-genai pyaudio

Set your Gemini API key (get one free from Google AI Studio):
   4)export GEMINI_API_KEY="YOUR_API_KEY_HERE"

Run the assistant through the terminal or Python IDE(Pycharm or VsCode):
   python jarvis.py

Stopping the Assistant

  5)Say "shutdown" or "go offline"

   or press Ctrl + C in the terminal
